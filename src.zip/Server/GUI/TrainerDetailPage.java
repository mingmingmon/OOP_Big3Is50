package Server.GUI;

public class TrainerDetailPage {
}
