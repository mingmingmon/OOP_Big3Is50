package Server.GUI;

import javax.swing.*;

public class HomeMiddlePanel extends JPanel {
    private JLabel imageLabel;
    private JLabel name;
    private JLabel continuityAttendanceDay;

    void setProfile(String name){

    }

}
